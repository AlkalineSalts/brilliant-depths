local example_event = Event.new("Example_Event")
local option = Option.new("Only Option", true)
example_event:add_option(option)


return example_event
